#
# TABLE STRUCTURE FOR: ___groups
#

DROP TABLE IF EXISTS `___groups`;

CREATE TABLE `___groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(250) NOT NULL,
  `group_level` smallint(8) NOT NULL,
  `date_added` int(10) DEFAULT '0',
  `date_updated` int(10) DEFAULT '0',
  `group_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `___groups` (`id`, `name`, `description`, `group_level`, `date_added`, `date_updated`, `group_active`) VALUES (1, 'admin', 'This group cannot be edited.', 99, 1426269333, 1452505640, 1);
INSERT INTO `___groups` (`id`, `name`, `description`, `group_level`, `date_added`, `date_updated`, `group_active`) VALUES (20, 'user', 'this group for newly registered users and cannot be edited.', 0, 1452741695, 1452741695, 1);


#
# TABLE STRUCTURE FOR: ___inbox_messages
#

DROP TABLE IF EXISTS `___inbox_messages`;

CREATE TABLE `___inbox_messages` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `from` int(9) NOT NULL,
  `to` int(9) NOT NULL,
  `date_sent` int(10) NOT NULL,
  `date_read` int(10) unsigned NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `from_username` varchar(100) NOT NULL,
  `to_username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `___inbox_messages` (`id`, `subject`, `message`, `from`, `to`, `date_sent`, `date_read`, `deleted`, `from_username`, `to_username`) VALUES (1, NULL, 'hello again', 1, 2, 1573474881, 1573474894, 0, 'sinan ARTUN', 'Dincer Pece');
INSERT INTO `___inbox_messages` (`id`, `subject`, `message`, `from`, `to`, `date_sent`, `date_read`, `deleted`, `from_username`, `to_username`) VALUES (2, NULL, 'selam canım', 2, 1, 1573474902, 1573474929, 0, 'Dincer Pece', 'sinan ARTUN');


#
# TABLE STRUCTURE FOR: ___login_attempts
#

DROP TABLE IF EXISTS `___login_attempts`;

CREATE TABLE `___login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `___login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES (1, '159.146.40.74', 'admin@admin.co', 1573473096);
INSERT INTO `___login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES (2, '159.146.40.74', 'admin@admin.co', 1573473134);
INSERT INTO `___login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES (3, '159.146.40.74', 'admin@admin.co', 1573473162);
INSERT INTO `___login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES (4, '159.146.40.74', 'admin@admin.co', 1573473444);


#
# TABLE STRUCTURE FOR: ___sent_messages
#

DROP TABLE IF EXISTS `___sent_messages`;

CREATE TABLE `___sent_messages` (
  `id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) DEFAULT NULL,
  `message` text,
  `from` int(9) NOT NULL,
  `to` int(9) NOT NULL,
  `date_sent` int(10) NOT NULL,
  `date_read` int(10) unsigned NOT NULL DEFAULT '0',
  `from_username` varchar(100) NOT NULL,
  `to_username` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ___system_logs
#

DROP TABLE IF EXISTS `___system_logs`;

CREATE TABLE `___system_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `time_unix` int(10) unsigned DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `log` varchar(255) DEFAULT NULL,
  `severity` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (1, 1573473092, 'logon', 'User Logged in Successfully  Username: synan54@gmail.com IP:88.131.7.130', 1);
INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (2, 1573473096, 'logon', 'Authentication Failed !!! Username: adminadminco IP:159.146.40.74', 8);
INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (3, 1573473134, 'logon', 'Authentication Failed !!! Username: adminadminco IP:159.146.40.74', 8);
INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (4, 1573473162, 'logon', 'Authentication Failed !!! Username: adminadminco IP:159.146.40.74', 8);
INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (5, 1573473444, 'logon', 'Authentication Failed !!! Username: adminadminco IP:159.146.40.74', 8);
INSERT INTO `___system_logs` (`id`, `time_unix`, `type`, `log`, `severity`) VALUES (6, 1573474726, 'logon', 'User Logged in Successfully  Username: dincerpece@gmail.com IP:159.146.40.74', 1);


#
# TABLE STRUCTURE FOR: ___users
#

DROP TABLE IF EXISTS `___users`;

CREATE TABLE `___users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `user_updated` int(10) DEFAULT '0',
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email_valid` tinyint(1) NOT NULL DEFAULT '0',
  `force_pass_update` tinyint(1) NOT NULL DEFAULT '0',
  `note` text,
  `website` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `table_add_advanced` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `language` varchar(10) DEFAULT NULL,
  `profile_img` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

INSERT INTO `___users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `user_updated`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `email_valid`, `force_pass_update`, `note`, `website`, `profile_pic`, `table_add_advanced`, `language`, `profile_img`) VALUES (1, '88.131.7.130', 'sinan', '$2y$08$dU93LU5qMNOH8fNCMiAZLu6hkN3DzbE3.r6Ug6.gd3tMGDuD3r3fK', NULL, 'synan54@gmail.com', NULL, NULL, NULL, 'LGWIVvopyCcqydhTYV8kj.', 1451776916, 0, 1573473092, 1, 'sinan', 'ARTUN', 'Hero company', '+905323235054', 0, 0, 'This is super-admin account. \nCan not be deleted or deactivated.', 'http://db-admin.net', NULL, 1, 'english', NULL);
INSERT INTO `___users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `user_updated`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `email_valid`, `force_pass_update`, `note`, `website`, `profile_pic`, `table_add_advanced`, `language`, `profile_img`) VALUES (2, '159.146.40.74', 'dincerpece@gmail.com', '$2y$08$3GsZPsc2rnS61QS/7KMI3.lG0IOH/x64n3jUpnQuho1tLycz7.pti', NULL, 'dincerpece@gmail.com', NULL, NULL, NULL, 'Bx6zOZgm6lG1kcoKbq/I2.', 1573473690, 0, 1573474726, 1, 'Dincer', 'Pece', NULL, NULL, 0, 0, NULL, NULL, NULL, 0, 'turkish', NULL);


#
# TABLE STRUCTURE FOR: ___users_groups
#

DROP TABLE IF EXISTS `___users_groups`;

CREATE TABLE `___users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `group_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `___users_groups` (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);
INSERT INTO `___users_groups` (`id`, `user_id`, `group_id`) VALUES (2, 2, 1);


